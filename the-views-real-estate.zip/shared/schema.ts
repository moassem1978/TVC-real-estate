export const properties = {}; // simplified schema placeholder
